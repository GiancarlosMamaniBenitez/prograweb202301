
const radios = document.getElementsByName("rdnTemp");
const selected = Array.from(radios).find(radio => radio.checked).value;


